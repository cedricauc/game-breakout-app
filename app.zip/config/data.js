module.exports = {
    mongoURI: 'mongodb+srv://admin:' + encodeURIComponent('youps34') + '@loginapp.ltrkgbz.mongodb.net/test',
    secret: "mysecretword"
}